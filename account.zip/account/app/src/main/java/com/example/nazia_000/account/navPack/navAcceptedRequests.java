package com.example.nazia_000.account.navPack;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.nazia_000.account.R;

public class navAcceptedRequests extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nav_accepted_requests);
    }
}
