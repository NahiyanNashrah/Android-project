package com.example.nazia_000.account.Adapter;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.nazia_000.account.R;
import com.example.nazia_000.account.classPack.ProfilesClass;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;
import com.squareup.picasso.Picasso;

import java.util.ConcurrentModificationException;

public class infoWindowAdapter implements GoogleMap.InfoWindowAdapter {

    private View mWindow;
    private Context context;

    private TextView nameTxt,nmbrTxt,grpTxt, adrsTxt, ageTxt;
    private ImageView img;
    private String nam,nmb,grp,adr;


    public infoWindowAdapter(Context context){
         this.context = context;

    }

    @Override
    public View getInfoWindow(Marker marker) {
        return null;
    }

    @Override
    public View getInfoContents(Marker marker) {

        try {
            View view = ((Activity) context).getLayoutInflater().inflate(R.layout.window_view, null);

            nameTxt = view.findViewById(R.id.winVListName);
            nmbrTxt = view.findViewById(R.id.winVListNumber);
            grpTxt = view.findViewById(R.id.winVListGrp);
            adrsTxt = view.findViewById(R.id.winVListLoc);
            ageTxt = view.findViewById(R.id.winVListAge);
            img = view.findViewById(R.id.winVImg);

            ProfilesClass profilesClass = (ProfilesClass) marker.getTag();

            nameTxt.setText(profilesClass.getname());
            nmbrTxt.setText(profilesClass.getnumber());
            grpTxt.setText(profilesClass.getblood_group());
            adrsTxt.setText(profilesClass.getaddress());
            ageTxt.setText(profilesClass.getAge());
            Picasso.get().load(profilesClass.getImgUri()).fit().into(img);


            return view;
        }catch (Exception e){}

        return  null;
    }
}
